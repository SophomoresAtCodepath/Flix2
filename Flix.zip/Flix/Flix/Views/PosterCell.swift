//
//  PosterCell.swift
//  Flix
//
//  Created by Donie Ypon on 9/13/18.
//  Copyright © 2018 Donie Ypon. All rights reserved.
//

import UIKit

class PosterCell: UICollectionViewCell {
    
    @IBOutlet weak var posterImageView: UIImageView!
    
    
}
